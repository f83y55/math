class Noeud:
    def __init__(self, etiquette, gauche, droit):
        self,etiq = etiquette
        self.sag = gauche
        self.sad = droit
